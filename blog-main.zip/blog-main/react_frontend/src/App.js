import "./App.css";
import BaseRoute from "./router/BaseRoute";

function App() {
  return <BaseRoute />;
}

export default App;
